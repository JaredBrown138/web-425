export interface PriceQuote{
    stockSymbol: string;
    lastPrice: number;
}